# ChessAssist Android — Magnus-inspired training mode

Versi latihan offline dengan mode analisis **Magnus-inspired**. Mode ini menggunakan prinsip catur umum yang sering diasosiasikan dengan permainan pemain elite: aktivitas buah, kontrol pusat, keselamatan raja, struktur/aktivitas posisi, dan endgame. Ini **bukan rekomendasi resmi Magnus Carlsen** dan bukan alat untuk memperoleh bantuan tersembunyi saat pertandingan online.

Build: buka folder ini di Android Studio lalu Build APK.
